print("Learning with Asad")
